﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Bride_Photo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)  // first time page load
        {
            if (Session["user"] == null)
                Response.Redirect("~/Account/Login.aspx");
            else
            {
                string un = Session["user"].ToString();
                imgPhoto.ImageUrl="~/images/"+ un+ ".jpg";
                HyperLink2.NavigateUrl = "~/images/" + un + ".jpg";

            }
        }
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        try
        {
            string fn = FileUpload1.FileName;
            string ext = System.IO.Path.GetExtension(fn);
            if (ext == ".jpg" || ext == ".png")
            {  
                string un = Session["user"].ToString();
                FileUpload1.SaveAs(Server.MapPath("~/images/") + un + ".jpg" );
                lblMsg.Text = "Picture Uploaded";
              

                imgPhoto.ImageUrl = "~/images/" + un + ".jpg";
            }
            else
                lblMsg.Text = "Invalid Picture File Type";
        }
        catch (Exception ex)
        {
            lblMsg.Text = "Error: " + ex.Message;
        }
    }
   
}