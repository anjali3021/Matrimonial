﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Bride_Details : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["un"] != null)
            {
                string fn = "../images/" + Request.QueryString["un"].ToString() + ".jpg";
                Image1.ImageUrl = fn;
            }
        }
    }
}