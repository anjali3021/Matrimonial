﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Bride_Expectations : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)  // first time page load
        {
            if (Session["user"] == null)
                Response.Redirect("~/Account/Login.aspx");
        }
    }
   
    protected void btnAdd_Click(object sender, EventArgs e)
    {
 SqlConnection con = new SqlConnection(HiddenField1.Value);
 SqlCommand cmd = new SqlCommand("insert into groomexpects(groomun,category,expectations) values(@groomun,@category,@expectations)", con);
 cmd.Parameters.AddWithValue("@groomun", Session["user"].ToString());

 cmd.Parameters.AddWithValue("@category", ddlCat.Text);
 cmd.Parameters.AddWithValue("@expectations", txtExp.Text);
       
        
        try 
	    {	        
		    con.Open();
            if (cmd.ExecuteNonQuery() > 0)
            {
                lblMSG.Text = "Expectations Added";
                txtExp.Text = "";
                GridView1.DataBind();

            }
            else
                lblMSG.Text = "Cannot Add Expectations ";

            con.Close();
	    }
	    catch (Exception ex)
	    {
            lblMSG.Text = "Error: " + ex.Message;
	    }
    }
}