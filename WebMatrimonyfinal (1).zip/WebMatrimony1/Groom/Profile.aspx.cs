﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;   // for sql server connectivity

public partial class Groom_Profile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)  // first time page load
        {
            if (Session["user"] == null)
                Response.Redirect("~/Account/Login.aspx");
            else
            {
                lblUN.Text = Session["user"].ToString();
                LoadProfile();  // udf
            }
        }
    }

    void LoadProfile()
    {
        SqlConnection con = new SqlConnection(HiddenField1.Value);
        SqlCommand cmd = 
            new SqlCommand("select * from groomprofile where username=@un",con);
        cmd.Parameters.AddWithValue("@un",lblUN.Text);
        try
        {
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                txtFN.Text = dr["FullName"].ToString();

                txtDOB.Text = DateTime.Parse(dr["DOB"].ToString()).ToString("dd-MMM-yyyy");
                txtHe.Text = dr["Height"].ToString();
                txtCol.Text = dr["Color"].ToString();
                txtEdu.Text = dr["Education"].ToString();
                txtJob.Text = dr["Job"].ToString();
                txtCast.Text = dr["Cast"].ToString();
                txtLoc.Text = dr["Location"].ToString();
                txtMob.Text = dr["Mobile"].ToString();
            }
            else
                lblMSG.Text = "Record Not Found";

            con.Close();
        }
        catch (Exception ex)
        {
            lblMSG.Text = "Error: " + ex.Message;
        }
    }

    protected void btnUP_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(HiddenField1.Value);
        SqlCommand cmd =
      new SqlCommand("update  GroomProfile set FullName=@fn,DOB=@dob,Height=@he,Color=@col,Education=@edu, Job=@job, Cast=@cast, Location=@loc, Mobile=@mob  where UserName=@un", con);

        cmd.Parameters.AddWithValue("@fn", txtFN.Text);
        cmd.Parameters.AddWithValue("@dob", txtDOB.Text);
        cmd.Parameters.AddWithValue("@he", txtHe.Text);
        cmd.Parameters.AddWithValue("@col", txtCol.Text);
        cmd.Parameters.AddWithValue("@edu", txtEdu.Text);
        cmd.Parameters.AddWithValue("@job", txtJob.Text);
        cmd.Parameters.AddWithValue("@cast", txtCast.Text);
        cmd.Parameters.AddWithValue("@loc", txtLoc.Text);
        cmd.Parameters.AddWithValue("@mob", txtMob.Text);
        cmd.Parameters.AddWithValue("@un", lblUN.Text);


        try
        {
            con.Open();
            if (cmd.ExecuteNonQuery() > 0)
                lblMSG.Text = "Profile Updated";
            else
                lblMSG.Text = "Cannot Update Profile";

            con.Close();
        }
        catch (Exception ex)
        {
            lblMSG.Text = "Error: " + ex.Message;
        }
             
    }
}