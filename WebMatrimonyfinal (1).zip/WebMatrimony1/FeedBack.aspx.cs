﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class FeedBack : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
 SqlConnection con = new SqlConnection(HiddenField1.Value);
 SqlCommand cmd = new SqlCommand("insert into feedback(ondate,fullname,contactinfo,comments) values(@ondate,@fullname,@contactinfo,@comments)", con);

 cmd.Parameters.AddWithValue("@ondate", DateTime.Now.ToString("dd-MMM-yyyy") );
 cmd.Parameters.AddWithValue("@fullname", txtFN.Text );
 cmd.Parameters.AddWithValue("@contactinfo", txtCI.Text);
 cmd.Parameters.AddWithValue("@comments", txtCmt.Text);

      
        
        try 
	    {	        
		    con.Open();
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Redirect("Thanks.aspx");
            }
            con.Close();
	    }
	    catch (Exception ex)
	    {
            Label1.Text = "Error: " + ex.Message;
	    }
    }
}